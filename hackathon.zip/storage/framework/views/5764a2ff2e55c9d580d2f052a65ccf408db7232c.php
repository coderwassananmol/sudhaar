<?php $__env->startSection('title'); ?> DOCUMENT YOUR CASE | SHARE IT GLOBALLY | SPREAD THE WORD | LET THE GOVT HEAR
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <script src="<?php echo e(asset('js/tooltip.min.js')); ?>" type="text/javascript"></script>
    <div class="popup">
        <div class="success"></div>
        <div class="a1">
            <div class="a2">
                <div class="a3">
                    <div class="a4">
                        <div class="a5">
                            <!-- Image credits: Pedro luis romani ruiz -->
                            <img src="https://upload.wikimedia.org/wikipedia/commons/7/7d/Pedro_luis_romani_ruiz.gif">
                            <p>Your case is uploading. <br />Please wait...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container addTopMargin" id="second">
        <div class="row">
                <form method="POST" action="/document" name="documentForm" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <h3 class="form-element-text"><?php if(session('language') != 'hi'): ?> <?php echo e('Choose a category'); ?> <?php else: ?> <?php echo e('कोई श्रेणी चुनें'); ?> <?php endif; ?></h3>
                    <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-4">
                            <button type="button" class="create-button ns" value="Administrative" name="category1" title="It includes all the cases that come under authority level like police,political etc."><?php if(session('language') != 'hi'): ?> <?php echo e('ADMINISTRATIVE'); ?> <?php else: ?> <?php echo e('प्रशासनिक'); ?> <?php endif; ?></button>
                        </div>
                        <div class="col-md-4">
                            <button type="button" class="create-button ns" value="Private sector" title="It includes all the content that come under the private sector such as matters involving private companies,hospitals etc." name="category2"><?php if(session('language') != 'hi'): ?> <?php echo e('PRIVATE SECTOR'); ?> <?php else: ?> <?php echo e('निजी क्षेत्र'); ?> <?php endif; ?></button>
                        </div>
                        <div class="col-md-4">
                            <button type="button" class="create-button ns" value="Education" name="category3" title="It involves all the matters that involves corruption in education."><?php if(session('language') != 'hi'): ?> <?php echo e('EDUCATION'); ?> <?php else: ?> <?php echo e('शिक्षा'); ?> <?php endif; ?></button>
                        </div>
                        <div class="col-md-4">
                            <button type="button" class="create-button ns" value="Media" name="category4" title="Category4"><?php if(session('language') != 'hi'): ?> <?php echo e('MEDIA'); ?> <?php else: ?> <?php echo e('मीडिया'); ?> <?php endif; ?></button>
                        </div>
                        <div class="col-md-4">
                            <button type="button" class="create-button ns" value="Religious" name="category5" title="Includes all the cases that came under exploiting someone's faith for private gain."><?php if(session('language') != 'hi'): ?> <?php echo e('RELIGIOUS'); ?> <?php else: ?> <?php echo e('धार्मिक'); ?> <?php endif; ?></button>
                        </div>
                    </div>
                    </div>
                    <div class="col-md-6">
                        <div class="category1">
                            <h3 class="form-element-text"><?php if(session('language') != 'hi'): ?> <?php echo e('Choose a sub-category'); ?> <?php else: ?> <?php echo e('उप-श्रेणी चुनें'); ?> <?php endif; ?></h3>
                            <button type="button" title="Misuse of power, Use of falsified evidence, Soliciting or accepting bribes, Evidence/investigation hiding" class="create-button sc" value="Police"><?php if(session('language') != 'hi'): ?> <?php echo e('POLICE'); ?> <?php else: ?> <?php echo e('पुलिस'); ?> <?php endif; ?></button>
                            <button type="button" title="Soliciting and accepting bribes, Extortion,Nepotism, Influence peddling to make decision in favour of etc." class="create-button sc" value="Political"><?php if(session('language') != 'hi'): ?> <?php echo e('POLITICAL'); ?> <?php else: ?> <?php echo e('राजनीतिक'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Judicial"><?php if(session('language') != 'hi'): ?> <?php echo e('JUDICIAL'); ?> <?php else: ?> <?php echo e('न्यायिक'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Sports"><?php if(session('language') != 'hi'): ?> <?php echo e('SPORTS'); ?> <?php else: ?> <?php echo e('खेल'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Scams"><?php if(session('language') != 'hi'): ?> <?php echo e('SCAMS'); ?> <?php else: ?> <?php echo e('घोटाले'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Health"><?php if(session('language') != 'hi'): ?> <?php echo e('HEALTH'); ?> <?php else: ?> <?php echo e('स्वास्थ्य'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Gender"><?php if(session('language') != 'hi'): ?> <?php echo e('GENDER'); ?> <?php else: ?> <?php echo e('लिंग'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Govt. Officials"><?php if(session('language') != 'hi'): ?> <?php echo e('GOVT. OFFICIALS'); ?> <?php else: ?> <?php echo e('सरकारी अधिकारी'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Defence and Security"><?php if(session('language') != 'hi'): ?> <?php echo e('DEFENCE AND SECURITY'); ?> <?php else: ?> <?php echo e('रक्षा और सुरक्षा'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Water"><?php if(session('language') != 'hi'): ?> <?php echo e('WATER'); ?> <?php else: ?> <?php echo e('जल'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Information Hiding"><?php if(session('language') != 'hi'): ?> <?php echo e('INFORMATION HIDING'); ?> <?php else: ?> <?php echo e('जानकारी छिपाना'); ?> <?php endif; ?></button>
                        </div>
                    <div class="category2">
                        <h3 class="form-element-text"><?php if(session('language') != 'hi'): ?> <?php echo e('Choose a sub-category'); ?> <?php else: ?> <?php echo e('उप-श्रेणी चुनें'); ?> <?php endif; ?></h3>
                        <button type="button" class="create-button sc" value="Private Companies"><?php if(session('language') != 'hi'): ?> <?php echo e('PRIVATE COMPANIES'); ?> <?php else: ?> <?php echo e('निजी कंपनियां'); ?> <?php endif; ?></button>
                        <button type="button" class="create-button sc" value="Health"><?php if(session('language') != 'hi'): ?> <?php echo e('HEALTH'); ?> <?php else: ?> <?php echo e('स्वास्थ्य'); ?> <?php endif; ?></button>
                    </div>
                        <div class="category5">
                            <h3 class="form-element-text">Choose a sub-category:</h3>
                            <button type="button" class="create-button sc" value="Exorcism"><?php if(session('language') != 'hi'): ?> <?php echo e('EXORCISM'); ?> <?php else: ?> <?php echo e('झाड़-फूंक'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Change of religion/case"><?php if(session('language') != 'hi'): ?> <?php echo e('CHANGE OF RELIGION/CASTE'); ?> <?php else: ?> <?php echo e('धर्म / जाति में बदलाव'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Fraud"><?php if(session('language') != 'hi'): ?> <?php echo e('FRAUD'); ?> <?php else: ?> <?php echo e('धोखा'); ?> <?php endif; ?></button>
                            <button type="button" class="create-button sc" value="Extortion"><?php if(session('language') != 'hi'): ?> <?php echo e('EXTORTION'); ?> <?php else: ?> <?php echo e('जबरन वसूली'); ?> <?php endif; ?></button>
                        </div>

                    <h3 class="form-element-text"><?php if(session('language') != 'hi'): ?> <?php echo e('Where did it happen?'); ?> <?php else: ?> <?php echo e('यह कहाँ हुआ?'); ?> <?php endif; ?></h3>
                    <input id="pac-input" class="controls form-control form-input-text" type="text" placeholder="Search Box" name="place" required>
                    <h3 class="form-element-text-nr"><?php if(session('language') != 'hi'): ?> <?php echo e('Name of the officer:'); ?> <?php else: ?> <?php echo e('अधिकारी का नाम:'); ?> <?php endif; ?></h3>
                    <input type="text" class="form-input-text form-control" name="officer">
                    <h3 class="form-element-text"><?php if(session('language') != 'hi'): ?> <?php echo e('What service you wanted?'); ?> <?php else: ?> <?php echo e('आप क्या सेवा चाहते थे?'); ?> <?php endif; ?></h3>
                    <input type="text" class="form-control form-input-text" name="service" required>
                    <h3 class="form-element-text"><?php if(session('language') != 'hi'): ?> <?php echo e('Tell us about your case..'); ?> <?php else: ?> <?php echo e('अपने मामले के बारे में हमें बताएं..'); ?> <?php endif; ?></h3>
                    <textarea class="form-input-text form-control" name="case" required></textarea>
                    <h3 class="form-element-text-nr"><?php if(session('language') != 'hi'): ?> <?php echo e('Do you have a proof'); ?> <?php else: ?> <?php echo e('क्या आपके पास सबूत है?'); ?> <?php endif; ?></h3>
                    <input type="checkbox" name="proof" value="1"><strong class="form-element-text-nr"><?php if(session('language') != 'hi'): ?> <?php echo e('Yes'); ?> <?php else: ?> <?php echo e('हाँ'); ?> <?php endif; ?></strong>
                    <br />
                    <div class="proof">
                        <h3 class="form-element-text"><?php if(session('language') != 'hi'): ?> <?php echo e('Please upload'); ?> <?php else: ?> <?php echo e('कृपया अपलोड करें'); ?> <?php endif; ?></h3>
                        <input type="file" class="fileupload" name="fileupload">
                    </div>
                    <h3 class="form-element-text-nr"><?php if(session('language') != 'hi'): ?> <?php echo e('Post Anonymously'); ?> <?php else: ?> <?php echo e('अनाम रूप से पोस्ट करें'); ?> <?php endif; ?></h3>
                    <input type="checkbox" name="anonymous" value="1" class="form-checkbox"><strong class="form-element-text-nr"><?php if(session('language') != 'hi'): ?> <?php echo e('Yes'); ?> <?php else: ?> <?php echo e('हाँ'); ?> <?php endif; ?></strong>
                    <br /><br />
                    <button type="submit" id="submit" class="create-button"><?php if(session('language') != 'hi'): ?> <?php echo e('SUBMIT THE CASE'); ?> <?php else: ?> <?php echo e('केस सबमिट करें'); ?> <?php endif; ?></button>
                </form>
            </div>
        </div>
    </div>
    <div class="container addTopMargin" id="first">
        <div class="row">
            <div class="col-md-6">
                <h1 class="main-title"><?php if(session('language') != 'hi'): ?> <?php echo e('DOCUMENT YOUR CASE.'); ?> <?php else: ?> <?php echo e('अपना केस दर्ज़ करें|'); ?> <?php endif; ?></h1>
            </div>
            <div class="col-md-6">
                <h1 class="main-title"><?php if(session('language') != 'hi'): ?> <?php echo e('SHARE IT GLOBALLY.'); ?> <?php else: ?> <?php echo e('विश्व स्तर पर इसे साझा करें|'); ?> <?php endif; ?></h1>
            </div>
            <div class="col-md-6">
                <h1 class="main-title"><?php if(session('language') != 'hi'): ?> <?php echo e('SPREAD THE WORD.'); ?> <?php else: ?> <?php echo e('प्रचार कीजिये|'); ?> <?php endif; ?></h1>
            </div>
            <div class="col-md-6">
                <h1 class="main-title"><?php if(session('language') != 'hi'): ?> <?php echo e('SPREAD THE WORD.'); ?> <?php else: ?> <?php echo e('सरकार तक बात पहुंचाएं|'); ?> <?php endif; ?></h1>
            </div>
        </div>
        <div class="col-md-6 col-md-push-5 addTopMargin">
            <button class="create-button"><?php if(session('language') != 'hi'): ?> <?php echo e('BEGIN!'); ?> <?php else: ?> <?php echo e('आरंभ करें!'); ?> <?php endif; ?></button>
        </div>
    </div>
    <script>
        $('#second').hide();
        $('.ns').on('click',function () {
            if($('.ns').hasClass('selected'))
            {
                $('.ns').removeClass('selected');
                $(this).addClass('selected');
            }
            else
            {
                $(this).addClass('selected');
            }
            switch($(this).val())
            {
                case 'Administrative':
                    $('.category2').hide();
                    $('.category3').hide();
                    $('.category4').hide();
                    $('.category5').hide();
                    $('.category1').fadeIn();
                    $('.sc').on('click',function(){
                        if($('.sc').hasClass('selected-sub'))
                        {
                            $('.sc').removeClass('selected-sub');
                            $(this).addClass('selected-sub');
                        }
                        else
                        {
                            $(this).addClass('selected-sub');
                        }
                    });
                    break;
                case 'Private sector':
                    $('.category1').hide();
                    $('.category3').hide();
                    $('.category4').hide();
                    $('.category5').hide();
                    $('.category2').fadeIn();
                    $('.sc').on('click',function(){
                        if($('.sc').hasClass('selected-sub'))
                        {
                            $('.sc').removeClass('selected-sub');
                            $(this).addClass('selected-sub');
                        }
                        else
                        {
                            $(this).addClass('selected-sub');
                        }
                    });
                    break;
                case 'Religious':
                    $('.category1').hide();
                    $('.category2').hide();
                    $('.category3').hide();
                    $('.category4').hide();
                    $('.category5').fadeIn();
                    $('.sc').on('click',function(){
                        if($('.sc').hasClass('selected-sub'))
                        {
                            $('.sc').removeClass('selected-sub');
                            $(this).addClass('selected-sub');
                        }
                        else
                        {
                            $(this).addClass('selected-sub');
                        }
                    });
                    break;
                default:
                    $('.category1').fadeOut();
                    $('.category2').fadeOut();
            }
        });
        $('input[name="proof"]').on('click',function () {
            var proof = $('.proof');
            if($(this).is(':checked'))
            {
                proof.fadeIn();
                proof.attr('required','required');
            }
            else
            {
                $('.proof').fadeOut();
                proof.removeAttr('required');
            }
        });
        $('form[name="documentForm"]').submit(function (event) {
            var category = $('.selected').val();
            var subcategory = $('.selected-sub').val();
            $('.popup').fadeIn();
            var proof;
            var anonymous;
            if($('input[name="proof"]').is(':checked'))
                proof = 1;
            else
                proof = 0;
            if($('input[name="anonymous"]').is(':checked'))
                anonymous = 1;
            else
                anonymous = 0;
            /*var formData = {
                'category'  : category,
                'place'     : $('input[name="place"]').val(),
                'officer'   : $('input[name="officer"]').val(),
                'service'   : $('input[name="service"]').val(),
                'case'      : $('textarea[name="case"]').val(),
                'fileupload': $('input[name="fileupload"]'),
                'proof'     : proof,
                'anonymous' : anonymous,
                '_token'    : $('input[name="_token"]').val()
            };*/
            var form = document.forms.namedItem('documentForm');
            var formData = new FormData(form);
            formData.append('category',category);
            formData.append('anonymous',anonymous);
            formData.append('subcat',subcategory);
            $.ajax({
                data : formData,
                url  : '/document',
                type : 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                processData: false,
                contentType: false
            })
                .done(function (data) {
                    $('.a5 img').attr('src','https://thumbs.gfycat.com/ShyCautiousAfricanpiedkingfisher-max-1mb.gif');
                    console.log(data);
                    $('.a5 p').html('Your case has been uploaded successfully! <br /> Redirecting you to the home page....');
                    setTimeout(function () {
                        window.location.href = '/';
                    },3000);
                })
                .fail(function (data) {
                    $('.a5 img').attr('src','https://images.vexels.com/media/users/3/134741/isolated/preview/07cfd1b48c4855217b811ddc85b5bf97-sad-emoji-emoticon-by-vexels.png');
                    console.log(data);
                    $('.a5 p').html('There was some error processing your request. <br /> Redirecting you to the home page....');
                    setTimeout(function () {
                        window.location.href = '/';
                    },3000);
                });
            event.preventDefault();
        });
        $('.create-button').on('click',function () {
            $('#first').fadeOut();
            $('#second').fadeIn();
        });
        function initAutocomplete() {
            // Create the search box and link it to the UI element.
            var searchBox = new google.maps.places.SearchBox(document.getElementById('pac-input'));
        }
    </script>
    <script type="text/javascript">
        $('button[name^="category"]').tooltipsy({
            offset: [10, 0],
            css: {
                'padding': '10px',
                'max-width': '150px',
                'color': '#4286f4',
                'font-family':'Open Sans',
                'background-color': '#fff',
                'border': '1px solid #deca7e',
                '-moz-box-shadow': '0 0 10px rgba(0, 0, 0, .5)',
                '-webkit-box-shadow': '0 0 10px rgba(0, 0, 0, .5)',
                'box-shadow': '0 0 10px rgba(0, 0, 0, .5)',
                'text-shadow': 'none'
            }
        });
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyATshlsUHZYvVVsFKM9LRGZKYPcPpJzAn0&libraries=places&callback=initAutocomplete" async defer></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>