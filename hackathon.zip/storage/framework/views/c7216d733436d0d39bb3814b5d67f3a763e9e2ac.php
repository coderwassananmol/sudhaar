<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="google-signin-client_id" content="376328505155-1kv7ipkgvb6nvilnhh2ubpbp9qm9u2lj.apps.googleusercontent.com">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,300|Open+Sans:700" rel="stylesheet" type="text/css">
    <link href="<?php echo e(URL::asset('css/app.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(URL::asset('css/app.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(URL::asset('css/style.css')); ?>" rel="stylesheet" type="text/css">
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/tipsy.js')); ?>" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
    <script src="https://apis.google.com/js/platform.js?onload=onLoad" async defer></script>

    <!-- Swiper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/js/swiper.min.js"></script>

    <script>
        function signOut() {
            var auth2 = gapi.auth2.getAuthInstance();
            auth2.signOut().then(function () {
                console.log('User signed out.');
                $('#logout-form').submit();
            });
        }

        function onLoad() {
            gapi.load('auth2', function() {
                gapi.auth2.init();
            });
        }
    </script>
</head>
<body>
<nav class="navbar navbar-default navbar-static-top">
    <div class="container">
        <div class="navbar-header">

            <!-- Collapsed Hamburger -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <!-- Branding Image -->
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <p class="brand-name">Sudhaar</p>
            </a>
        </div>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Left Side Of Navbar -->
            <ul class="nav navbar-nav">
                &nbsp;
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right right-navbar">
                <!-- Authentication Links -->
                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>"> <?php if(session('language') == 'hi'): ?> <?php echo e('लॉग इन करें'); ?> <?php else: ?> <?php echo e('Login'); ?> <?php endif; ?> </a></li>
                    <li><a href="<?php echo e(route('register')); ?>"> <?php if(session('language') == 'hi'): ?> <?php echo e('साइन अप करें'); ?> <?php else: ?> <?php echo e('Sign up'); ?> <?php endif; ?> </a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php if(session('language') == 'hi'): ?> <?php echo e('भाषा'); ?> <?php else: ?> <?php echo e('Language'); ?> <?php endif; ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="/en" name="en">English (EN)</a>
                            </li>
                            <li>
                                <a href="/hi" name="en">हिंदी (HI)</a>
                            </li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="/"> <?php if(session('language') == 'hi'): ?> <?php echo e('घर'); ?> <?php else: ?>  <?php echo e('Home'); ?> <?php endif; ?> </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('home')); ?>"> <?php if(session('language') == 'hi'): ?> <?php echo e('डैशबोर्ड'); ?> <?php else: ?> <?php echo e('Dashboard'); ?> <?php endif; ?> </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('document')); ?>"> <?php if(session('language') == 'hi'): ?> <?php echo e('एक केस जोड़ें'); ?> <?php else: ?> <?php echo e('Add a case'); ?> <?php endif; ?> </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('report')); ?>"> <?php if(session('language') == 'hi'): ?> <?php echo e('सभी मामलों को देखें'); ?> <?php else: ?> <?php echo e('View all cases'); ?> <?php endif; ?> </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                   onclick="signOut()">
                                    <?php if(session('language') == 'hi'): ?> <?php echo e('लोग आउट'); ?> <?php else: ?> <?php echo e('Log out'); ?> <?php endif; ?>
                                    <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php if(session('language') == 'hi'): ?> <?php echo e('भाषा'); ?> <?php else: ?> <?php echo e('Language'); ?> <?php endif; ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="/en" name="en">English (EN)</a>
                            </li>
                            <li>
                                <a href="/hi" name="en">हिंदी (HI)</a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php echo $__env->yieldContent('body'); ?>
</body>
</html>