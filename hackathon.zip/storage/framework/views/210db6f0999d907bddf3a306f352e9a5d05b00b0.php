<?php $__env->startSection('body'); ?>
<div class="container addTopMargin">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading text-center fileupload">Welcome, <?php echo e(Auth::user()->name); ?>!</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <p class="main-title">What would you like to do today?</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <a href="/document">
                        <button class="create-button addBottomMargin">Report a new person/organization</button>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="/report">
                        <button class="create-button addBottomMargin">View your existing case(s)</button>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="/generatepetition">
                        <button class="create-button">Generate a petition (under construction)</button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>