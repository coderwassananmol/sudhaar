<?php $__env->startSection('body'); ?>
    <div class="container addTopMargin">
        <div class="row">
                <h2 class="main-title">Check all your uploaded cases here.</h2>
                <?php
                $users = App\hackModel::where('userid',Auth::user()->id)->get();
                foreach($users as $case) { ?>
            <div class="col-md-6 addBottomMargin">
                <div class="latestnews">
                    <img src="https://i.imgur.com/R9J2bFi.png" class="img-small">
                    <p class="name"><?php if($case->anonymous == 1): ?> <?php echo e('Anonymous'); ?> <?php else: ?> <?php echo e(Auth::user()->name); ?><?php endif; ?></p>
                    <p class="place">&mdash; <?php echo e($case->place); ?>, <?php echo e($case->created_at); ?></p>
                    <p class="culprit"><strong><?php echo e('Report submitted against: '); ?></strong><strong style="color: #ff1a1a"><?php echo e($case->officer); ?></strong></p>
                    <p class="service"><strong>Service: </strong><strong style="color: #ff1a1a0;"><?php echo e($case->service); ?></strong></p>
                    <p class="category"><strong>Category: <?php echo e($case->category); ?></strong></p>
                    <p class="subcat"><strong>Sub-Category: <?php echo e($case->subcat); ?></strong></p>
                    <p class="proof">
                        <strong>Proof uploaded:</strong>
                            <?php if($case->proof == 0): ?>
                                <?php echo e('No'); ?>

                            <?php else: ?>
                                <?php echo e('Yes'); ?>

                            <?php endif; ?>
                    </p>
                    <p class="case" style="display: block">Case: <?php echo e($case->case); ?></p>
                </div>
            </div>
                <?php
                } ?>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>